package application;

public class Informacion {

	public void MostrarInformacion(){
		System.out.println("En proceso");
	}
}
